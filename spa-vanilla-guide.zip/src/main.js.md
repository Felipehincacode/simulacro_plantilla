# 🚀 Main.js - Corazón de la SPA

## 🎯 Propósito
Archivo principal que inicializa y coordina toda la Single Page Application. Actúa como el "cerebro" que conecta todos los módulos, maneja el estado global y controla el ciclo de vida de la aplicación.

## 📋 Arquitectura Explicada

### Importaciones y Dependencias
\`\`\`javascript
import { Router } from './utils/router.js'
import { AuthService } from './services/auth.js'
import { StorageService } from './utils/storage.js'
import { Header } from './components/header.js'
import { Sidebar } from './components/sidebar.js'
\`\`\`

**Explicación de cada importación:**
- `Router`: Sistema de rutas personalizado para SPA
- `AuthService`: Manejo de autenticación y autorización
- `StorageService`: Abstracción de localStorage/sessionStorage
- `Header/Sidebar`: Componentes de layout reutilizables
- `Pages`: Componentes de página para cada ruta

### Clase App - Arquitectura Principal
\`\`\`javascript
class App {
    constructor() {
        this.router = null
        this.authService = new AuthService()
        this.storageService = new StorageService()
        this.currentUser = null
        
        // Bind methods para mantener contexto
        this.init = this.init.bind(this)
    }
}
\`\`\`

**Propiedades principales:**
- `router`: Instancia del sistema de rutas
- `authService`: Servicio de autenticación
- `storageService`: Servicio de almacenamiento
- `currentUser`: Estado del usuario actual
- `header/sidebar`: Componentes del layout

## 🚀 Proceso de Inicialización

### Método init() - Secuencia de Arranque
\`\`\`javascript
async init() {
    try {
        // 1. Verificar autenticación inicial
        await this.checkAuthentication()
        
        // 2. Configurar router con rutas
        this.setupRouter()
        
        // 3. Renderizar layout base
        this.renderLayout()
        
        // 4. Inicializar router
        this.router.init()
        
        // 5. Ocultar loading inicial
        this.hideInitialLoading()
    } catch (error) {
        this.showError('Error al cargar la aplicación')
    }
}
\`\`\`

**Explicación paso a paso:**

#### 1. Verificación de Autenticación
\`\`\`javascript
async checkAuthentication() {
    const token = this.storageService.getItem('authToken')
    const userData = this.storageService.getItem('currentUser')
    
    if (token && userData) {
        const isValid = await this.authService.validateToken(token)
        if (isValid) {
            this.currentUser = userData
        } else {
            this.authService.logout()
        }
    }
}
\`\`\`

**Lógica:**
- Busca token y datos de usuario en storage
- Valida token con el servidor
- Si es válido, restaura sesión
- Si no, limpia datos y logout

#### 2. Configuración del Router
\`\`\`javascript
setupRouter() {
    const routes = {
        '/': {
            component: PublicPage,
            title: 'Inicio - SPA Vanilla Guide',
            requiresAuth: false,
            allowedRoles: ['admin', 'visitor', 'guest']
        },
        '/dashboard': {
            component: DashboardPage,
            title: 'Dashboard - Panel de Administración',
            requiresAuth: true,
            allowedRoles: ['admin']
        }
    }
}
\`\`\`

**Configuración de rutas:**
- `component`: Clase de la página a renderizar
- `title`: Título que aparece en la pestaña
- `requiresAuth`: Si requiere autenticación
- `allowedRoles`: Roles que pueden acceder
- `redirectIfAuth`: Redirección si ya está autenticado

## 🎨 Sistema de Layout

### Renderizado del Layout Base
\`\`\`javascript
renderLayout() {
    const app = document.getElementById('app')
    
    app.innerHTML = `
        <div class="app-container">
            <header id="app-header" class="app-header"></header>
            
            <div class="main-container">
                <aside id="app-sidebar" class="app-sidebar"></aside>
                
                <main id="app-content" class="app-content">
                    <div id="page-container" class="page-container">
                        <!-- Páginas dinámicas aquí -->
                    </div>
                </main>
            </div>
            
            <div id="modal-overlay" class="modal-overlay hidden"></div>
            <div id="notifications-container" class="notifications-container"></div>
        </div>
    `
}
\`\`\`

**Estructura explicada:**
- `app-container`: Contenedor principal de la aplicación
- `app-header`: Header fijo con navegación y usuario
- `app-sidebar`: Sidebar con menú de navegación
- `page-container`: Donde se cargan las páginas dinámicamente
- `modal-overlay`: Para modales y popups
- `notifications-container`: Para notificaciones toast

### Inicialización de Componentes
\`\`\`javascript
initializeLayoutComponents() {
    this.header = new Header({
        container: document.getElementById('app-header'),
        currentUser: this.currentUser,
        onLogout: this.handleLogout.bind(this),
        onProfileClick: this.handleProfileClick.bind(this)
    })
    
    this.sidebar = new Sidebar({
        container: document.getElementById('app-sidebar'),
        currentUser: this.currentUser,
        onNavigate: this.handleNavigation.bind(this)
    })
}
\`\`\`

**Patrón de inicialización:**
- Cada componente recibe su contenedor DOM
- Se pasa el estado necesario (currentUser)
- Se definen callbacks para comunicación

## 🛣️ Sistema de Rutas

### Manejo de Cambios de Ruta
\`\`\`javascript
handleRouteChange(route, params) {
    // Actualizar título de la página
    document.title = this.router.getCurrentRoute()?.title
    
    // Actualizar sidebar activo
    this.sidebar.updateActiveRoute(route)
    
    // Scroll al top
    window.scrollTo(0, 0)
}
\`\`\`

### Protección de Rutas
\`\`\`javascript
handleAuthRequired() {
    this.showNotification('Debes iniciar sesión', 'warning')
    this.router.navigate('/login')
}

handleAccessDenied() {
    this.showNotification('No tienes permisos', 'error')
    this.router.navigate('/')
}
\`\`\`

## 🔐 Manejo de Autenticación

### Logout Global
\`\`\`javascript
async handleLogout() {
    try {
        await this.authService.logout()
        this.currentUser = null
        
        // Actualizar componentes
        this.header.updateUser(null)
        this.sidebar.updateUser(null)
        
        // Redirigir
        this.router.navigate('/')
        
        this.showNotification('Sesión cerrada', 'success')
    } catch (error) {
        this.showNotification('Error al cerrar sesión', 'error')
    }
}
\`\`\`

### Actualización de Estado
\`\`\`javascript
handleAuthChange(user) {
    this.currentUser = user
    
    // Propagar cambios a componentes
    if (this.header) this.header.updateUser(user)
    if (this.sidebar) this.sidebar.updateUser(user)
}
\`\`\`

## 🎧 Event Listeners Globales

### Manejo de Errores
\`\`\`javascript
setupGlobalEventListeners() {
    // Errores JavaScript globales
    window.addEventListener('error', (event) => {
        console.error('Error global:', event.error)
        this.showNotification('Ha ocurrido un error', 'error')
    })
    
    // Promesas rechazadas
    window.addEventListener('unhandledrejection', (event) => {
        console.error('Promesa rechazada:', event.reason)
        this.showNotification('Error en operación', 'error')
    })
}
\`\`\`

### Sincronización entre Pestañas
\`\`\`javascript
// Detectar cambios en localStorage de otras pestañas
window.addEventListener('storage', (event) => {
    if (event.key === 'authToken' && !event.newValue) {
        // Token eliminado en otra pestaña
        this.handleLogout()
    }
})
\`\`\`

### Estado de Conexión
\`\`\`javascript
window.addEventListener('online', () => {
    this.showNotification('Conexión restaurada', 'success')
})

window.addEventListener('offline', () => {
    this.showNotification('Sin conexión', 'warning')
})
\`\`\`

## 🔔 Sistema de Notificaciones

### Mostrar Notificación
\`\`\`javascript
showNotification(message, type = 'info', duration = 5000) {
    const container = document.getElementById('notifications-container')
    
    const notification = document.createElement('div')
    notification.className = `notification notification-${type} fade-in`
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                ×
            </button>
        </div>
    `
    
    container.appendChild(notification)
    
    // Auto-remove
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove()
        }
    }, duration)
}
\`\`\`

**Tipos de notificación:**
- `info`: Información general (azul)
- `success`: Operación exitosa (verde)
- `warning`: Advertencia (amarillo)
- `error`: Error (rojo)

## 📱 Responsive Design

### Manejo de Resize
\`\`\`javascript
handleResize() {
    const isMobile = window.innerWidth <= 768
    
    if (this.sidebar) {
        this.sidebar.handleResize(isMobile)
    }
}
\`\`\`

### CSS Responsive
\`\`\`css
@media (max-width: 768px) {
    .app-sidebar {
        position: fixed;
        transform: translateX(-100%);
        z-index: 200;
    }
    
    .app-sidebar.open {
        transform: translateX(0);
    }
}
\`\`\`

## 🚀 Comandos de Terminal

### Desarrollo
\`\`\`bash
# Iniciar aplicación completa
npm run dev

# Solo frontend (si backend ya corre)
npm run frontend

# Debugging con logs detallados
DEBUG=* npm run dev
\`\`\`

### Testing Manual
\`\`\`bash
# Abrir DevTools del navegador
# F12 o Ctrl+Shift+I

# En Console, probar:
window.appDebug.getState()
window.appDebug.navigate('/dashboard')
window.appDebug.showNotification('Test', 'success')
\`\`\`

## 🔧 Debugging y Desarrollo

### Debug Tools (Solo en desarrollo)
\`\`\`javascript
if (import.meta.env.DEV) {
    window.appDebug = {
        getState: () => window.app.getState(),
        navigate: (route) => window.app.router.navigate(route),
        showNotification: (msg, type) => window.app.showNotification(msg, type),
        getCurrentUser: () => window.app.currentUser
    }
}
\`\`\`

### Hot Module Replacement
\`\`\`javascript
if (import.meta.hot) {
    import.meta.hot.accept(() => {
        console.log('Hot reload detectado')
        window.location.reload()
    })
}
\`\`\`

## 📊 Estado de la Aplicación

### Método getState()
\`\`\`javascript
getState() {
    return {
        currentUser: this.currentUser,
        currentRoute: this.router?.getCurrentRoute(),
        isAuthenticated: !!this.currentUser
    }
}
\`\`\`

**Información disponible:**
- Usuario actual y sus datos
- Ruta actual y parámetros
- Estado de autenticación
- Configuración del router

## 🐛 Manejo de Errores

### Error Crítico
\`\`\`javascript
showError(message) {
    const app = document.getElementById('app')
    app.innerHTML = `
        <div class="error-container">
            <div class="error-content">
                <h1>⚠️ Error</h1>
                <p>${message}</p>
                <button onclick="window.location.reload()">
                    Recargar Página
                </button>
            </div>
        </div>
    `
}
\`\`\`

### Recuperación de Errores
- Botón de recarga automática
- Limpieza de storage corrupto
- Fallback a página de inicio
- Logs detallados para debugging

## 📈 Optimizaciones de Performance

### Lazy Loading de Componentes
\`\`\`javascript
// Importación dinámica de páginas
const loadPage = async (pageName) => {
    const module = await import(`./pages/${pageName}.js`)
    return module.default
}
\`\`\`

### Debounce de Eventos
\`\`\`javascript
const debouncedResize = debounce(this.handleResize, 250)
window.addEventListener('resize', debouncedResize)
\`\`\`

### Cleanup de Event Listeners
\`\`\`javascript
destroy() {
    // Limpiar listeners al destruir la app
    window.removeEventListener('error', this.handleError)
    window.removeEventListener('resize', this.handleResize)
}
\`\`\`

## 🔗 Enlaces Útiles
- [ES6 Modules](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)
- [Event Handling](https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener)
- [Error Handling](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling)
- [Local Storage](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage)

---
**Siguiente paso**: Implementar el sistema de rutas en `utils/router.js`
