/**
 * 🚀 MAIN.JS - Punto de entrada principal de la SPA
 *
 * Este archivo inicializa la aplicación, configura el router,
 * maneja la autenticación inicial y coordina todos los módulos.
 *
 * Autor: Felipe Hincapié
 * Fecha: 2025
 */

// Importaciones de módulos principales
import { Router } from "./utils/router.js"
import { AuthService } from "./services/auth.js"
import { StorageService } from "./utils/storage.js"
import { Header } from "./components/header.js"
import { Sidebar } from "./components/sidebar.js"

// Importación de páginas
import { LoginPage } from "./pages/login.js"
import { RegisterPage } from "./pages/register.js"
import { DashboardPage } from "./pages/dashboard.js"
import { PublicPage } from "./pages/public.js"

/**
 * 🎯 Clase principal de la aplicación
 * Coordina la inicialización y el ciclo de vida de la SPA
 */
class App {
  constructor() {
    this.router = null
    this.authService = new AuthService()
    this.storageService = new StorageService()
    this.header = null
    this.sidebar = null
    this.currentUser = null

    // Bind methods
    this.init = this.init.bind(this)
    this.setupRouter = this.setupRouter.bind(this)
    this.checkAuthentication = this.checkAuthentication.bind(this)
    this.handleAuthChange = this.handleAuthChange.bind(this)
    this.renderLayout = this.renderLayout.bind(this)
  }

  /**
   * 🚀 Inicialización principal de la aplicación
   */
  async init() {
    try {
      console.log("🚀 Iniciando SPA Vanilla Guide...")

      // 1. Verificar autenticación inicial
      await this.checkAuthentication()

      // 2. Configurar router con rutas
      this.setupRouter()

      // 3. Renderizar layout base
      this.renderLayout()

      // 4. Inicializar router
      this.router.init()

      // 5. Ocultar loading inicial
      this.hideInitialLoading()

      // 6. Setup event listeners globales
      this.setupGlobalEventListeners()

      console.log("✅ Aplicación inicializada correctamente")
    } catch (error) {
      console.error("❌ Error al inicializar la aplicación:", error)
      this.showError("Error al cargar la aplicación. Por favor, recarga la página.")
    }
  }

  /**
   * 🛣️ Configuración del sistema de rutas
   */
  setupRouter() {
    const routes = {
      "/": {
        component: PublicPage,
        title: "Inicio - SPA Vanilla Guide",
        requiresAuth: false,
        allowedRoles: ["admin", "visitor", "guest"],
      },
      "/login": {
        component: LoginPage,
        title: "Iniciar Sesión",
        requiresAuth: false,
        allowedRoles: ["guest"],
        redirectIfAuth: "/",
      },
      "/register": {
        component: RegisterPage,
        title: "Registrarse",
        requiresAuth: false,
        allowedRoles: ["guest"],
        redirectIfAuth: "/",
      },
      "/dashboard": {
        component: DashboardPage,
        title: "Dashboard - Panel de Administración",
        requiresAuth: true,
        allowedRoles: ["admin"],
      },
      "/courses": {
        component: PublicPage,
        title: "Cursos Disponibles",
        requiresAuth: false,
        allowedRoles: ["admin", "visitor", "guest"],
      },
      "/my-courses": {
        component: PublicPage,
        title: "Mis Cursos",
        requiresAuth: true,
        allowedRoles: ["visitor"],
      },
      "/profile": {
        component: PublicPage,
        title: "Mi Perfil",
        requiresAuth: true,
        allowedRoles: ["admin", "visitor"],
      },
    }

    this.router = new Router(routes, {
      onRouteChange: this.handleRouteChange.bind(this),
      onAuthRequired: this.handleAuthRequired.bind(this),
      onAccessDenied: this.handleAccessDenied.bind(this),
    })
  }

  /**
   * 🔐 Verificación de autenticación inicial
   */
  async checkAuthentication() {
    try {
      const token = this.storageService.getItem("authToken")
      const userData = this.storageService.getItem("currentUser")

      if (token && userData) {
        // Verificar si el token sigue siendo válido
        const isValid = await this.authService.validateToken(token)

        if (isValid) {
          this.currentUser = userData
          console.log("👤 Usuario autenticado:", userData.name)
        } else {
          // Token inválido, limpiar storage
          this.authService.logout()
          this.currentUser = null
        }
      } else {
        this.currentUser = null
        console.log("👤 Usuario no autenticado")
      }
    } catch (error) {
      console.error("❌ Error al verificar autenticación:", error)
      this.currentUser = null
    }
  }

  /**
   * 🎨 Renderizado del layout principal
   */
  renderLayout() {
    const app = document.getElementById("app")

    // Estructura HTML base de la aplicación
    app.innerHTML = `
            <div class="app-container">
                <!-- Header principal -->
                <header id="app-header" class="app-header"></header>
                
                <!-- Contenedor principal -->
                <div class="main-container">
                    <!-- Sidebar de navegación -->
                    <aside id="app-sidebar" class="app-sidebar"></aside>
                    
                    <!-- Contenido principal -->
                    <main id="app-content" class="app-content">
                        <div id="page-container" class="page-container">
                            <!-- Aquí se cargan las páginas dinámicamente -->
                        </div>
                    </main>
                </div>
                
                <!-- Overlay para modales -->
                <div id="modal-overlay" class="modal-overlay hidden"></div>
                
                <!-- Contenedor de notificaciones -->
                <div id="notifications-container" class="notifications-container"></div>
            </div>
        `

    // Inicializar componentes del layout
    this.initializeLayoutComponents()

    // Aplicar estilos del layout
    this.applyLayoutStyles()
  }

  /**
   * 🧩 Inicialización de componentes del layout
   */
  initializeLayoutComponents() {
    // Inicializar Header
    this.header = new Header({
      container: document.getElementById("app-header"),
      currentUser: this.currentUser,
      onLogout: this.handleLogout.bind(this),
      onProfileClick: this.handleProfileClick.bind(this),
    })

    // Inicializar Sidebar
    this.sidebar = new Sidebar({
      container: document.getElementById("app-sidebar"),
      currentUser: this.currentUser,
      onNavigate: this.handleNavigation.bind(this),
    })

    // Renderizar componentes
    this.header.render()
    this.sidebar.render()
  }

  /**
   * 🎨 Aplicar estilos CSS del layout
   */
  applyLayoutStyles() {
    const styles = `
            <style>
                .app-container {
                    min-height: 100vh;
                    display: flex;
                    flex-direction: column;
                }
                
                .app-header {
                    position: sticky;
                    top: 0;
                    z-index: 100;
                    background: var(--bg-primary);
                    border-bottom: 1px solid var(--border-color);
                    box-shadow: var(--shadow-sm);
                }
                
                .main-container {
                    flex: 1;
                    display: flex;
                    min-height: calc(100vh - 64px);
                }
                
                .app-sidebar {
                    width: 250px;
                    background: var(--bg-primary);
                    border-right: 1px solid var(--border-color);
                    transition: transform var(--transition-normal);
                }
                
                .app-sidebar.collapsed {
                    transform: translateX(-100%);
                }
                
                .app-content {
                    flex: 1;
                    background: var(--bg-secondary);
                    overflow-y: auto;
                }
                
                .page-container {
                    padding: var(--spacing-lg);
                    max-width: 1200px;
                    margin: 0 auto;
                }
                
                .modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    z-index: 1000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .notifications-container {
                    position: fixed;
                    top: 80px;
                    right: var(--spacing-lg);
                    z-index: 1100;
                    max-width: 400px;
                }
                
                /* Responsive Design */
                @media (max-width: 768px) {
                    .app-sidebar {
                        position: fixed;
                        top: 64px;
                        left: 0;
                        height: calc(100vh - 64px);
                        z-index: 200;
                        transform: translateX(-100%);
                    }
                    
                    .app-sidebar.open {
                        transform: translateX(0);
                    }
                    
                    .page-container {
                        padding: var(--spacing-md);
                    }
                }
                
                /* Animaciones */
                .fade-in {
                    animation: fadeIn 0.3s ease-in-out;
                }
                
                .slide-in {
                    animation: slideIn 0.3s ease-out;
                }
                
                @keyframes slideIn {
                    from {
                        transform: translateX(-20px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            </style>
        `

    document.head.insertAdjacentHTML("beforeend", styles)
  }

  /**
   * 🔄 Manejo de cambios de ruta
   */
  handleRouteChange(route, params) {
    console.log("🛣️ Navegando a:", route)

    // Actualizar título de la página
    document.title = this.router.getCurrentRoute()?.title || "SPA Vanilla Guide"

    // Actualizar sidebar activo
    if (this.sidebar) {
      this.sidebar.updateActiveRoute(route)
    }

    // Scroll al top en cambio de página
    window.scrollTo(0, 0)
  }

  /**
   * 🔐 Manejo cuando se requiere autenticación
   */
  handleAuthRequired() {
    console.log("🔐 Autenticación requerida, redirigiendo a login")
    this.showNotification("Debes iniciar sesión para acceder a esta página", "warning")
    this.router.navigate("/login")
  }

  /**
   * 🚫 Manejo de acceso denegado
   */
  handleAccessDenied() {
    console.log("🚫 Acceso denegado por permisos insuficientes")
    this.showNotification("No tienes permisos para acceder a esta página", "error")
    this.router.navigate("/")
  }

  /**
   * 🚪 Manejo de logout
   */
  async handleLogout() {
    try {
      await this.authService.logout()
      this.currentUser = null

      // Actualizar componentes
      this.header.updateUser(null)
      this.sidebar.updateUser(null)

      // Redirigir a inicio
      this.router.navigate("/")

      this.showNotification("Sesión cerrada correctamente", "success")
    } catch (error) {
      console.error("❌ Error al cerrar sesión:", error)
      this.showNotification("Error al cerrar sesión", "error")
    }
  }

  /**
   * 👤 Manejo de click en perfil
   */
  handleProfileClick() {
    this.router.navigate("/profile")
  }

  /**
   * 🧭 Manejo de navegación desde sidebar
   */
  handleNavigation(route) {
    this.router.navigate(route)
  }

  /**
   * 🔄 Manejo de cambios en autenticación
   */
  handleAuthChange(user) {
    this.currentUser = user

    // Actualizar componentes
    if (this.header) {
      this.header.updateUser(user)
    }

    if (this.sidebar) {
      this.sidebar.updateUser(user)
    }

    console.log("🔄 Estado de autenticación actualizado:", user ? user.name : "No autenticado")
  }

  /**
   * 🎧 Configurar event listeners globales
   */
  setupGlobalEventListeners() {
    // Manejo de errores globales
    window.addEventListener("error", (event) => {
      console.error("❌ Error global:", event.error)
      this.showNotification("Ha ocurrido un error inesperado", "error")
    })

    // Manejo de promesas rechazadas
    window.addEventListener("unhandledrejection", (event) => {
      console.error("❌ Promesa rechazada:", event.reason)
      this.showNotification("Error en operación asíncrona", "error")
    })

    // Manejo de cambios en el storage (para múltiples pestañas)
    window.addEventListener("storage", (event) => {
      if (event.key === "authToken" && !event.newValue) {
        // Token eliminado en otra pestaña
        this.handleLogout()
      }
    })

    // Manejo de resize para responsive
    window.addEventListener("resize", () => {
      this.handleResize()
    })

    // Manejo de online/offline
    window.addEventListener("online", () => {
      this.showNotification("Conexión restaurada", "success")
    })

    window.addEventListener("offline", () => {
      this.showNotification("Sin conexión a internet", "warning")
    })
  }

  /**
   * 📱 Manejo de resize para responsive
   */
  handleResize() {
    const isMobile = window.innerWidth <= 768

    if (this.sidebar) {
      this.sidebar.handleResize(isMobile)
    }
  }

  /**
   * 🔔 Mostrar notificación
   */
  showNotification(message, type = "info", duration = 5000) {
    const container = document.getElementById("notifications-container")
    if (!container) return

    const notification = document.createElement("div")
    notification.className = `notification notification-${type} fade-in`
    notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                    ×
                </button>
            </div>
        `

    container.appendChild(notification)

    // Auto-remove después del duration
    setTimeout(() => {
      if (notification.parentElement) {
        notification.remove()
      }
    }, duration)

    // Aplicar estilos si no existen
    this.ensureNotificationStyles()
  }

  /**
   * 🎨 Asegurar estilos de notificaciones
   */
  ensureNotificationStyles() {
    if (document.getElementById("notification-styles")) return

    const styles = document.createElement("style")
    styles.id = "notification-styles"
    styles.textContent = `
            .notification {
                background: var(--bg-primary);
                border-radius: var(--border-radius);
                box-shadow: var(--shadow-lg);
                margin-bottom: var(--spacing-sm);
                border-left: 4px solid var(--primary-color);
                overflow: hidden;
            }
            
            .notification-success {
                border-left-color: var(--success-color);
            }
            
            .notification-error {
                border-left-color: var(--error-color);
            }
            
            .notification-warning {
                border-left-color: var(--warning-color);
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: var(--spacing-md);
            }
            
            .notification-message {
                flex: 1;
                font-size: var(--font-size-sm);
                color: var(--text-primary);
            }
            
            .notification-close {
                background: none;
                border: none;
                font-size: var(--font-size-lg);
                cursor: pointer;
                color: var(--text-secondary);
                padding: 0;
                margin-left: var(--spacing-md);
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .notification-close:hover {
                color: var(--text-primary);
            }
        `

    document.head.appendChild(styles)
  }

  /**
   * ❌ Mostrar error crítico
   */
  showError(message) {
    const app = document.getElementById("app")
    app.innerHTML = `
            <div class="error-container">
                <div class="error-content">
                    <h1>⚠️ Error</h1>
                    <p>${message}</p>
                    <button onclick="window.location.reload()" class="btn btn-primary">
                        Recargar Página
                    </button>
                </div>
            </div>
        `

    // Estilos para error crítico
    const errorStyles = `
            <style>
                .error-container {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    background: var(--bg-secondary);
                }
                
                .error-content {
                    text-align: center;
                    padding: var(--spacing-xl);
                    background: var(--bg-primary);
                    border-radius: var(--border-radius);
                    box-shadow: var(--shadow-lg);
                    max-width: 400px;
                }
                
                .error-content h1 {
                    color: var(--error-color);
                    margin-bottom: var(--spacing-md);
                }
                
                .error-content p {
                    color: var(--text-secondary);
                    margin-bottom: var(--spacing-lg);
                }
            </style>
        `

    document.head.insertAdjacentHTML("beforeend", errorStyles)
  }

  /**
   * 🫥 Ocultar loading inicial
   */
  hideInitialLoading() {
    const loading = document.getElementById("initial-loading")
    if (loading) {
      loading.style.opacity = "0"
      setTimeout(() => {
        loading.remove()
      }, 300)
    }
  }

  /**
   * 🔄 Método público para actualizar autenticación
   */
  updateAuth(user) {
    this.handleAuthChange(user)
  }

  /**
   * 📊 Obtener estado de la aplicación
   */
  getState() {
    return {
      currentUser: this.currentUser,
      currentRoute: this.router?.getCurrentRoute(),
      isAuthenticated: !!this.currentUser,
    }
  }
}

/**
 * 🚀 Inicialización de la aplicación
 * Se ejecuta cuando el DOM está completamente cargado
 */
document.addEventListener("DOMContentLoaded", async () => {
  // Crear instancia global de la aplicación
  window.app = new App()

  // Inicializar aplicación
  await window.app.init()

  // Exponer métodos útiles globalmente para debugging
  if (import.meta.env.DEV) {
    window.appDebug = {
      getState: () => window.app.getState(),
      navigate: (route) => window.app.router.navigate(route),
      showNotification: (msg, type) => window.app.showNotification(msg, type),
      getCurrentUser: () => window.app.currentUser,
    }

    console.log("🔧 Debug tools available in window.appDebug")
  }
})

/**
 * 🔄 Hot Module Replacement para desarrollo
 * Solo se ejecuta en modo desarrollo con Vite
 */
if (import.meta.hot) {
  import.meta.hot.accept(() => {
    console.log("🔄 Hot reload detectado, recargando...")
    window.location.reload()
  })
}

// Exportar para testing
export { App }
