# 🌐 Index.html - Punto de Entrada de la SPA

## 🎯 Propósito
Archivo HTML principal que sirve como punto de entrada único para nuestra Single Page Application. Define la estructura base, estilos globales y configuración inicial.

## 📋 Estructura Explicada

### DOCTYPE y Configuración Base
\`\`\`html
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPA Vanilla Guide - Sistema de Gestión de Cursos</title>
\`\`\`

**Explicación línea por línea:**
- `<!DOCTYPE html>`: Declara HTML5
- `lang="es"`: Idioma español para accesibilidad
- `charset="UTF-8"`: Codificación de caracteres
- `viewport`: Configuración responsive para móviles
- `title`: Título que aparece en la pestaña del navegador

### Meta Tags para SEO
\`\`\`html
<meta name="description" content="Sistema de gestión de cursos...">
<meta name="keywords" content="SPA, JavaScript, Vite...">
<meta name="author" content="Felipe Hincapié">
\`\`\`

**Propósito de cada meta tag:**
- `description`: Descripción para motores de búsqueda
- `keywords`: Palabras clave para SEO
- `author`: Información del autor

### Open Graph para Redes Sociales
\`\`\`html
<meta property="og:title" content="SPA Vanilla Guide">
<meta property="og:description" content="Sistema completo...">
<meta property="og:type" content="website">
\`\`\`

**Funcionalidad:**
- Mejora la apariencia al compartir en redes sociales
- Define título, descripción y tipo de contenido
- Esencial para marketing digital

### Optimizaciones de Performance
\`\`\`html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
\`\`\`

**Explicación:**
- `preconnect`: Establece conexión temprana con servidores
- Reduce latencia al cargar Google Fonts
- Mejora el tiempo de carga inicial

### Variables CSS Personalizadas
\`\`\`css
:root {
    --primary-color: #3b82f6;
    --primary-dark: #2563eb;
    --bg-primary: #ffffff;
    --text-primary: #1e293b;
    /* ... más variables */
}
\`\`\`

**Ventajas del sistema de variables:**
- **Consistencia**: Colores uniformes en toda la app
- **Mantenibilidad**: Cambios centralizados
- **Temas**: Fácil implementación de modo oscuro
- **Escalabilidad**: Agregar nuevos colores es simple

### Reset CSS Moderno
\`\`\`css
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: var(--font-family);
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
\`\`\`

**Propósito:**
- Elimina estilos por defecto del navegador
- Establece `box-sizing: border-box` globalmente
- Mejora la renderización de fuentes
- Base consistente para todos los navegadores

### Sistema de Utilidades CSS
\`\`\`css
.btn {
    display: inline-flex;
    align-items: center;
    padding: var(--spacing-sm) var(--spacing-md);
    border-radius: var(--border-radius);
    transition: all var(--transition-fast);
}

.btn-primary {
    background-color: var(--primary-color);
    color: white;
}
\`\`\`

**Clases utilitarias incluidas:**
- `.btn`, `.btn-primary`, `.btn-secondary`: Botones
- `.card`: Tarjetas con sombra
- `.loading`: Spinner de carga
- `.alert-*`: Mensajes de estado
- `.hidden`, `.sr-only`: Utilidades de visibilidad

### Contenedor Principal
\`\`\`html
<div id="app">
    <div id="initial-loading" class="loading-container">
        <div class="loading-spinner">
            <div class="loading"></div>
            <p>Cargando aplicación...</p>
        </div>
    </div>
</div>
\`\`\`

**Estructura explicada:**
- `#app`: Contenedor donde se monta la SPA
- `#initial-loading`: Loading screen inicial
- Se oculta cuando la app está lista

### Carga del JavaScript Principal
\`\`\`html
<script type="module" src="/src/main.js"></script>
\`\`\`

**Características:**
- `type="module"`: Habilita ES6 modules
- Carga asíncrona y no bloquea el HTML
- Vite procesa este archivo como punto de entrada

## 🎨 Sistema de Diseño

### Paleta de Colores
\`\`\`css
/* Colores principales */
--primary-color: #3b82f6;     /* Azul principal */
--success-color: #10b981;     /* Verde éxito */
--warning-color: #f59e0b;     /* Amarillo advertencia */
--error-color: #ef4444;       /* Rojo error */

/* Colores de fondo */
--bg-primary: #ffffff;        /* Fondo principal */
--bg-secondary: #f8fafc;      /* Fondo secundario */
--bg-tertiary: #f1f5f9;       /* Fondo terciario */
\`\`\`

### Tipografía
\`\`\`css
--font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
--font-size-xs: 0.75rem;      /* 12px */
--font-size-sm: 0.875rem;     /* 14px */
--font-size-base: 1rem;       /* 16px */
--font-size-lg: 1.125rem;     /* 18px */
\`\`\`

### Espaciado Consistente
\`\`\`css
--spacing-xs: 0.25rem;        /* 4px */
--spacing-sm: 0.5rem;         /* 8px */
--spacing-md: 1rem;           /* 16px */
--spacing-lg: 1.5rem;         /* 24px */
--spacing-xl: 2rem;           /* 32px */
\`\`\`

## 📱 Responsive Design

### Breakpoints
\`\`\`css
/* Mobile first approach */
@media (max-width: 768px) {
    .container {
        padding: 0 var(--spacing-sm);
    }
    
    .btn {
        padding: var(--spacing-xs) var(--spacing-sm);
        font-size: var(--font-size-xs);
    }
}
\`\`\`

### Viewport Configuration
\`\`\`html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
\`\`\`

**Configuración explicada:**
- `width=device-width`: Ancho igual al dispositivo
- `initial-scale=1.0`: Zoom inicial al 100%
- Esencial para responsive design

## 🔧 Optimizaciones de Performance

### Preload de Recursos Críticos
\`\`\`html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
\`\`\`

### Font Display Optimization
\`\`\`html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
\`\`\`

**`display=swap` significa:**
- Muestra fuente de respaldo inmediatamente
- Cambia a fuente personalizada cuando carga
- Evita FOIT (Flash of Invisible Text)

### Service Worker (PWA)
\`\`\`javascript
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            });
    });
}
\`\`\`

**Funcionalidad:**
- Habilita capacidades offline
- Cache de recursos estáticos
- Mejora la experiencia de usuario

## 🎯 Accesibilidad

### Elementos Semánticos
\`\`\`html
<html lang="es">  <!-- Idioma para lectores de pantalla -->
\`\`\`

### Screen Reader Support
\`\`\`css
.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
}
\`\`\`

### Focus Management
\`\`\`css
.btn:focus {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}
\`\`\`

## 🐛 Debugging y Desarrollo

### Console Logs
\`\`\`javascript
console.log('SW registered: ', registration);
console.log('SW registration failed: ', registrationError);
\`\`\`

### Error Boundaries
\`\`\`css
.alert-error {
    background-color: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
}
\`\`\`

## 🚀 Comandos de Terminal

### Desarrollo
\`\`\`bash
# Iniciar servidor de desarrollo
npm run dev

# Solo frontend (si backend ya está corriendo)
npm run frontend
\`\`\`

### Build
\`\`\`bash
# Construir para producción
npm run build

# Preview del build
npm run preview
\`\`\`

### Debugging
\`\`\`bash
# Inspeccionar con herramientas de desarrollo
# F12 en el navegador
# Console, Network, Elements tabs
\`\`\`

## 📊 Métricas de Performance

### Core Web Vitals
- **LCP (Largest Contentful Paint)**: < 2.5s
- **FID (First Input Delay)**: < 100ms
- **CLS (Cumulative Layout Shift)**: < 0.1

### Optimizaciones Implementadas
- CSS crítico inline
- Preconnect a recursos externos
- Font display swap
- Lazy loading de imágenes
- Service Worker para cache

## 🔗 Enlaces Útiles
- [HTML5 Specification](https://html.spec.whatwg.org/)
- [CSS Custom Properties](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)
- [Web Accessibility](https://www.w3.org/WAI/)
- [Core Web Vitals](https://web.dev/vitals/)

---
**Siguiente paso**: Configurar el archivo principal `main.js` y el sistema de rutas
