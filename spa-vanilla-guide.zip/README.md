# 🚀 SPA Vanilla JavaScript - Guía Completa de Proyecto

## 📋 Descripción del Proyecto
Single Page Application (SPA) desarrollada con JavaScript Vanilla, Vite, npm y json-server. Sistema completo de gestión de usuarios y cursos con autenticación y roles diferenciados.

## 🎯 Objetivos de Aprendizaje
- Crear una SPA sin frameworks
- Implementar CRUD completo con métodos HTTP
- Sistema de autenticación y autorización
- Manejo de rutas dinámicas
- Arquitectura modular y escalable

## 🛠️ Tecnologías Utilizadas
- **Frontend**: HTML5, CSS3, JavaScript ES6+
- **Build Tool**: Vite
- **Package Manager**: npm
- **Backend Simulado**: json-server
- **Storage**: localStorage

## 📁 Estructura del Proyecto
\`\`\`
spa-vanilla/
├── src/
│   ├── assets/
│   │   └── styles/
│   ├── components/
│   │   ├── header.js
│   │   ├── sidebar.js
│   │   └── modal.js
│   ├── pages/
│   │   ├── login.js
│   │   ├── register.js
│   │   ├── dashboard.js
│   │   └── public.js
│   ├── services/
│   │   ├── auth.js
│   │   ├── users.js
│   │   ├── courses.js
│   │   └── enrollments.js
│   ├── utils/
│   │   ├── validation.js
│   │   ├── storage.js
│   │   └── router.js
│   └── main.js
├── db.json
├── index.html
├── package.json
└── vite.config.js
\`\`\`

## 🚀 Comandos de Instalación

### 1. Crear proyecto con Vite
\`\`\`bash
npm create vite@latest spa-vanilla -- --template vanilla
cd spa-vanilla
npm install
\`\`\`

### 2. Instalar json-server
\`\`\`bash
npm install --save-dev json-server
npm install --save-dev concurrently
\`\`\`

### 3. Scripts en package.json
\`\`\`json
{
  "scripts": {
    "dev": "concurrently \"npm run backend\" \"npm run frontend\"",
    "frontend": "vite",
    "backend": "json-server --watch db.json --port 3001",
    "build": "vite build",
    "preview": "vite preview"
  }
}
\`\`\`

### 4. Ejecutar el proyecto
\`\`\`bash
npm run dev
\`\`\`

## 🔧 Configuración Inicial

### Vite Config (vite.config.js)
\`\`\`javascript
import { defineConfig } from 'vite'

export default defineConfig({
  server: {
    port: 3000
  },
  build: {
    outDir: 'dist'
  }
})
\`\`\`

## 📊 Base de Datos (db.json)
Estructura de datos para json-server con usuarios, cursos y matrículas.

## 🏗️ Arquitectura del Proyecto

### Patrón de Diseño
- **MVC**: Separación de lógica, vista y datos
- **Modular**: Cada funcionalidad en su propio módulo
- **SPA Router**: Sistema de rutas personalizado
- **Service Layer**: Abstracción de llamadas HTTP

### Flujo de Datos
1. **Router** → Carga página correspondiente
2. **Page** → Utiliza servicios para obtener datos
3. **Service** → Realiza peticiones HTTP a json-server
4. **Component** → Renderiza UI y maneja eventos

## 🔐 Sistema de Autenticación
- Registro de usuarios
- Login con validación
- Roles: Admin y Visitante
- Persistencia con localStorage
- Protección de rutas

## 📱 Funcionalidades

### Para Administradores
- ✅ CRUD completo de usuarios
- ✅ CRUD completo de cursos
- ✅ Gestión de matrículas
- ✅ Dashboard administrativo

### Para Visitantes
- ✅ Registro e inicio de sesión
- ✅ Visualización de cursos
- ✅ Inscripción a cursos
- ✅ Vista de cursos inscritos

## 🎨 Interfaz de Usuario
- Diseño responsivo
- Sidebar de navegación
- Header con información de usuario
- Modales para formularios
- Tablas para listados
- Formularios de validación

## 📚 Guías Detalladas
Cada archivo del proyecto incluye su documentación .md con:
- Propósito y funcionalidad
- Explicación línea por línea
- Comandos utilizados
- Ejemplos de uso
- Mejores prácticas

## 🧪 Testing y Validación
- Validación de formularios
- Manejo de errores HTTP
- Feedback visual al usuario
- Validación de roles y permisos

## 🚀 Despliegue
\`\`\`bash
npm run build
# Los archivos se generan en /dist
\`\`\`

## 📖 Recursos Adicionales
- [Documentación de Vite](https://vitejs.dev/)
- [JSON Server](https://github.com/typicode/json-server)
- [MDN Web Docs](https://developer.mozilla.org/)

---
**Autor**: Felipe Hincapié  
**Fecha**: 2025  
**Versión**: 1.0.0
