# ⚡ Vite.config.js - Configuración del Build Tool

## 🎯 Propósito
Archivo de configuración de Vite que define cómo se construye y sirve nuestra SPA. Optimiza el desarrollo y la producción.

## 📋 Configuración Explicada

### Importación Base
\`\`\`javascript
import { defineConfig } from 'vite'
\`\`\`
- **defineConfig**: Función helper de Vite
- **Ventaja**: Autocompletado y validación TypeScript
- **Tipo**: Configuración tipada

### Servidor de Desarrollo
\`\`\`javascript
server: {
  port: 3000,
  open: true,
  cors: true,
  proxy: {
    '/api': {
      target: 'http://localhost:3001',
      changeOrigin: true,
      rewrite: (path) => path.replace(/^\/api/, '')
    }
  }
}
\`\`\`

**Explicación detallada:**

#### Puerto y Apertura
- `port: 3000`: Puerto del servidor de desarrollo
- `open: true`: Abre navegador automáticamente
- `cors: true`: Habilita Cross-Origin Resource Sharing

#### Proxy Configuration
- **Propósito**: Redirigir requests de API
- **Patrón**: `/api/*` → `http://localhost:3001/*`
- **changeOrigin**: Cambia el header Origin
- **rewrite**: Remueve `/api` del path

**Ejemplo de uso:**
\`\`\`javascript
// En el código frontend
fetch('/api/users') // Se redirige a http://localhost:3001/users
\`\`\`

### Configuración de Build
\`\`\`javascript
build: {
  outDir: 'dist',
  assetsDir: 'assets',
  sourcemap: true,
  minify: 'terser',
  rollupOptions: {
    output: {
      manualChunks: {
        vendor: ['vite']
      }
    }
  }
}
\`\`\`

**Explicación línea por línea:**

#### Directorios
- `outDir: 'dist'`: Carpeta de salida del build
- `assetsDir: 'assets'`: Subcarpeta para assets estáticos

#### Optimización
- `sourcemap: true`: Mapas de código para debugging
- `minify: 'terser'`: Minificador más eficiente

#### Code Splitting
- `manualChunks`: Separación manual de código
- `vendor`: Chunk separado para dependencias

### Configuración CSS
\`\`\`javascript
css: {
  devSourcemap: true
}
\`\`\`
- **devSourcemap**: Source maps para CSS en desarrollo
- **Ventaja**: Debugging de estilos más fácil

### Variables de Entorno
\`\`\`javascript
define: {
  __APP_VERSION__: JSON.stringify(process.env.npm_package_version)
}
\`\`\`
- **define**: Variables globales en tiempo de build
- **__APP_VERSION__**: Versión desde package.json

## 🚀 Comandos de Terminal

### Desarrollo
\`\`\`bash
# Iniciar servidor de desarrollo
npm run frontend

# Con configuración específica
npx vite --port 3000 --open
\`\`\`

### Build
\`\`\`bash
# Build para producción
npm run build

# Preview del build
npm run preview

# Build con análisis
npx vite build --mode analyze
\`\`\`

### Debugging
\`\`\`bash
# Modo debug
DEBUG=vite:* npm run frontend

# Información del build
npx vite build --debug
\`\`\`

## 🔧 Configuraciones Avanzadas

### Múltiples Entornos
\`\`\`javascript
export default defineConfig(({ command, mode }) => {
  const config = {
    // Configuración base
  }
  
  if (command === 'serve') {
    // Configuración para desarrollo
    config.server = {
      port: 3000
    }
  } else {
    // Configuración para build
    config.build = {
      minify: 'terser'
    }
  }
  
  return config
})
\`\`\`

### Plugins Útiles
\`\`\`javascript
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [
    // Plugin para HTML múltiple
    {
      name: 'html-transform',
      transformIndexHtml(html) {
        return html.replace('{{TITLE}}', 'SPA Vanilla Guide')
      }
    }
  ]
})
\`\`\`

### Alias de Rutas
\`\`\`javascript
import { resolve } from 'path'

export default defineConfig({
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@components': resolve(__dirname, 'src/components'),
      '@services': resolve(__dirname, 'src/services'),
      '@utils': resolve(__dirname, 'src/utils')
    }
  }
})
\`\`\`

## 📊 Estructura de Build

### Desarrollo
\`\`\`
http://localhost:3000/
├── src/ (servido directamente)
├── Hot Module Replacement
└── Source Maps habilitados
\`\`\`

### Producción
\`\`\`
dist/
├── index.html
├── assets/
│   ├── index-[hash].js
│   ├── index-[hash].css
│   └── vendor-[hash].js
└── sourcemaps (opcional)
\`\`\`

## 🐛 Solución de Problemas

### Error: Puerto ocupado
\`\`\`javascript
server: {
  port: 3000,
  strictPort: false // Busca puerto disponible
}
\`\`\`

### Error: CORS
\`\`\`javascript
server: {
  cors: {
    origin: ['http://localhost:3001'],
    credentials: true
  }
}
\`\`\`

### Error: Build lento
\`\`\`javascript
build: {
  rollupOptions: {
    external: ['large-dependency']
  }
}
\`\`\`

## 📈 Optimizaciones de Performance

### Code Splitting Inteligente
\`\`\`javascript
build: {
  rollupOptions: {
    output: {
      manualChunks(id) {
        if (id.includes('node_modules')) {
          return 'vendor'
        }
        if (id.includes('src/components')) {
          return 'components'
        }
      }
    }
  }
}
\`\`\`

### Preload de Recursos
\`\`\`javascript
build: {
  rollupOptions: {
    output: {
      assetFileNames: 'assets/[name]-[hash][extname]'
    }
  }
}
\`\`\`

## 🔗 Enlaces Útiles
- [Vite Configuration](https://vitejs.dev/config/)
- [Rollup Options](https://rollupjs.org/guide/en/#configuration-files)
- [Terser Minifier](https://terser.org/)

---
**Siguiente paso**: Configurar base de datos con `db.json`
