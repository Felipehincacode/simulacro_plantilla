# 📦 Package.json - Guía Detallada

## 🎯 Propósito
El archivo `package.json` es el corazón de nuestro proyecto Node.js. Define las dependencias, scripts y metadatos del proyecto SPA.

## 📋 Contenido Explicado

### Información Básica
\`\`\`json
{
  "name": "spa-vanilla-guide",
  "private": true,
  "version": "1.0.0",
  "type": "module"
}
\`\`\`

**Explicación línea por línea:**
- `name`: Nombre único del proyecto
- `private`: Evita publicación accidental en npm
- `version`: Versión semántica del proyecto
- `type`: "module" habilita ES6 modules

### Scripts de Desarrollo
\`\`\`json
"scripts": {
  "dev": "concurrently \"npm run backend\" \"npm run frontend\"",
  "frontend": "vite",
  "backend": "json-server --watch db.json --port 3001 --delay 500"
}
\`\`\`

**Comandos explicados:**

#### `npm run dev`
- **Función**: Ejecuta frontend y backend simultáneamente
- **Herramienta**: `concurrently` para procesos paralelos
- **Uso**: Comando principal para desarrollo

#### `npm run frontend`
- **Función**: Inicia servidor de desarrollo Vite
- **Puerto**: 3000 (por defecto)
- **Hot Reload**: Recarga automática en cambios

#### `npm run backend`
- **Función**: Inicia json-server
- **Puerto**: 3001
- **Archivo**: Observa `db.json`
- **Delay**: 500ms para simular latencia real

### Dependencias de Desarrollo
\`\`\`json
"devDependencies": {
  "vite": "^5.0.8",
  "json-server": "^0.17.4",
  "concurrently": "^8.2.2"
}
\`\`\`

**Explicación de cada dependencia:**

#### Vite (^5.0.8)
- **Propósito**: Build tool y dev server
- **Ventajas**: 
  - Inicio rápido
  - Hot Module Replacement
  - Build optimizado
- **Configuración**: `vite.config.js`

#### JSON Server (^0.17.4)
- **Propósito**: API REST falsa
- **Funcionalidad**:
  - CRUD automático
  - Rutas RESTful
  - Middleware personalizable
- **Archivo**: `db.json`

#### Concurrently (^8.2.2)
- **Propósito**: Ejecutar múltiples comandos
- **Uso**: Frontend + Backend simultáneo
- **Ventaja**: Un solo comando para todo

## 🚀 Comandos de Terminal

### Instalación Inicial
\`\`\`bash
# Crear proyecto
npm create vite@latest spa-vanilla -- --template vanilla

# Navegar al directorio
cd spa-vanilla

# Instalar dependencias base
npm install

# Instalar dependencias de desarrollo
npm install --save-dev json-server concurrently
\`\`\`

### Comandos de Desarrollo
\`\`\`bash
# Desarrollo completo (recomendado)
npm run dev

# Solo frontend
npm run frontend

# Solo backend
npm run backend

# Build para producción
npm run build

# Preview del build
npm run preview
\`\`\`

### Comandos de Mantenimiento
\`\`\`bash
# Limpiar proyecto
npm run clean

# Reinstalar dependencias
npm run setup

# Ver dependencias desactualizadas
npm outdated

# Actualizar dependencias
npm update
\`\`\`

## 🔧 Configuración Avanzada

### Scripts Adicionales Útiles
\`\`\`json
"scripts": {
  "test": "echo 'No tests specified'",
  "lint": "echo 'No linting configured'",
  "format": "echo 'No formatting configured'",
  "deploy": "npm run build && echo 'Ready for deployment'"
}
\`\`\`

### Variables de Entorno
\`\`\`bash
# .env (crear en raíz)
VITE_API_URL=http://localhost:3001
VITE_APP_NAME=SPA Vanilla Guide
\`\`\`

## 📊 Estructura de Dependencias

\`\`\`
spa-vanilla-guide/
├── node_modules/
│   ├── vite/
│   ├── json-server/
│   └── concurrently/
├── package.json
├── package-lock.json
└── node_modules/
\`\`\`

## 🐛 Solución de Problemas

### Error: Puerto en uso
\`\`\`bash
# Encontrar proceso en puerto 3000
lsof -ti:3000

# Matar proceso
kill -9 $(lsof -ti:3000)
\`\`\`

### Error: Dependencias faltantes
\`\`\`bash
# Limpiar cache npm
npm cache clean --force

# Reinstalar
rm -rf node_modules package-lock.json
npm install
\`\`\`

## 📈 Mejores Prácticas

1. **Versionado Semántico**: Usar ^ para actualizaciones menores
2. **Scripts Descriptivos**: Nombres claros y funcionales
3. **Dependencias Separadas**: dev vs production
4. **Documentación**: Comentarios en scripts complejos

## 🔗 Enlaces Útiles
- [npm Documentation](https://docs.npmjs.com/)
- [Semantic Versioning](https://semver.org/)
- [Vite Guide](https://vitejs.dev/guide/)
- [JSON Server](https://github.com/typicode/json-server)

---
**Siguiente paso**: Configurar `vite.config.js` y estructura de carpetas
