import { defineConfig } from "vite"

export default defineConfig({
  // Configuración del servidor de desarrollo
  server: {
    port: 3000,
    open: true, // Abre automáticamente el navegador
    cors: true, // Habilita CORS para json-server
    proxy: {
      // Proxy para API requests
      "/api": {
        target: "http://localhost:3001",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
    },
  },

  // Configuración de build
  build: {
    outDir: "dist",
    assetsDir: "assets",
    sourcemap: true, // Para debugging en producción
    minify: "terser", // Minificación optimizada
    rollupOptions: {
      output: {
        manualChunks: {
          // Separar vendor code
          vendor: ["vite"],
        },
      },
    },
  },

  // Configuración de CSS
  css: {
    devSourcemap: true,
  },

  // Variables de entorno
  define: {
    __APP_VERSION__: JSON.stringify(process.env.npm_package_version),
  },
})
