# 🗄️ DB.json - Base de Datos del Proyecto

## 🎯 Propósito
Archivo de base de datos JSON que simula una API REST completa usando json-server. Contiene toda la estructura de datos para usuarios, cursos, matrículas y sesiones.

## 📊 Estructura de Datos Explicada

### 👥 Tabla: Users
\`\`\`json
{
  "id": 1,
  "name": "Admin Principal",
  "email": "admin@admin.com",
  "password": "admin123",
  "role": "admin",
  "phone": "1234567890",
  "enrollNumber": "ADM001",
  "dateOfAdmission": "01-Jan-2020",
  "avatar": "https://ui-avatars.com/api/?name=Admin+Principal",
  "status": "active",
  "createdAt": "2020-01-01T00:00:00.000Z",
  "updatedAt": "2025-01-01T00:00:00.000Z"
}
\`\`\`

**Campos explicados:**
- `id`: Identificador único (Primary Key)
- `name`: Nombre completo del usuario
- `email`: Email único para login
- `password`: Contraseña (en producción debe estar hasheada)
- `role`: "admin" o "visitor" para control de acceso
- `phone`: Número de teléfono
- `enrollNumber`: Número de matrícula único
- `dateOfAdmission`: Fecha de registro
- `avatar`: URL de imagen de perfil
- `status`: Estado del usuario (active/inactive)
- `createdAt/updatedAt`: Timestamps de auditoría

### 📚 Tabla: Courses
\`\`\`json
{
  "id": 1,
  "title": "Introducción a JavaScript",
  "description": "Curso básico de JavaScript desde cero...",
  "instructor": "Felipe Hincapié",
  "startDate": "10-Jul-2025",
  "endDate": "10-Aug-2025",
  "duration": "4 semanas",
  "level": "Principiante",
  "category": "Programación",
  "price": 99.99,
  "maxStudents": 30,
  "currentStudents": 2,
  "image": "https://images.unsplash.com/photo-...",
  "status": "active",
  "syllabus": ["Variables y tipos", "Funciones..."],
  "createdAt": "2024-12-01T00:00:00.000Z"
}
\`\`\`

**Campos explicados:**
- `title`: Nombre del curso
- `description`: Descripción detallada
- `instructor`: Nombre del instructor
- `startDate/endDate`: Fechas de inicio y fin
- `duration`: Duración en formato legible
- `level`: Nivel de dificultad
- `category`: Categoría del curso
- `price`: Precio en USD
- `maxStudents`: Cupo máximo
- `currentStudents`: Estudiantes actuales
- `image`: URL de imagen del curso
- `syllabus`: Array con temario del curso

### 🎓 Tabla: Enrollments
\`\`\`json
{
  "id": 1,
  "userId": 2,
  "courseId": 1,
  "enrollmentDate": "2024-12-15T00:00:00.000Z",
  "status": "active",
  "progress": 25,
  "completedLessons": 3,
  "totalLessons": 12,
  "grade": null,
  "certificateIssued": false,
  "paymentStatus": "paid",
  "paymentDate": "2024-12-15T00:00:00.000Z",
  "notes": "Estudiante muy participativo"
}
\`\`\`

**Campos explicados:**
- `userId`: Referencia al usuario (Foreign Key)
- `courseId`: Referencia al curso (Foreign Key)
- `enrollmentDate`: Fecha de inscripción
- `status`: Estado de la matrícula
- `progress`: Porcentaje de progreso (0-100)
- `completedLessons`: Lecciones completadas
- `totalLessons`: Total de lecciones
- `grade`: Calificación final
- `certificateIssued`: Si se emitió certificado
- `paymentStatus`: Estado del pago
- `notes`: Notas adicionales

### 🔐 Tabla: Sessions
\`\`\`json
{
  "id": 1,
  "userId": 1,
  "token": "admin_session_token_123",
  "loginTime": "2025-01-13T22:59:51.000Z",
  "lastActivity": "2025-01-13T22:59:51.000Z",
  "ipAddress": "127.0.0.1",
  "userAgent": "Mozilla/5.0...",
  "isActive": true
}
\`\`\`

**Campos explicados:**
- `userId`: Usuario de la sesión
- `token`: Token único de sesión
- `loginTime`: Momento del login
- `lastActivity`: Última actividad
- `ipAddress`: IP del usuario
- `userAgent`: Información del navegador
- `isActive`: Si la sesión está activa

### 🔔 Tabla: Notifications
\`\`\`json
{
  "id": 1,
  "userId": 2,
  "title": "Bienvenido al curso",
  "message": "Te has inscrito exitosamente...",
  "type": "success",
  "read": false,
  "createdAt": "2024-12-15T00:00:00.000Z"
}
\`\`\`

## 🚀 Comandos de JSON Server

### Iniciar Servidor
\`\`\`bash
# Comando básico
json-server --watch db.json

# Con puerto específico
json-server --watch db.json --port 3001

# Con delay para simular latencia
json-server --watch db.json --port 3001 --delay 500

# Con CORS habilitado
json-server --watch db.json --port 3001 --middlewares ./middleware.js
\`\`\`

### Rutas Automáticas Generadas
\`\`\`
GET    /users          # Obtener todos los usuarios
GET    /users/1        # Obtener usuario por ID
POST   /users          # Crear nuevo usuario
PUT    /users/1        # Actualizar usuario completo
PATCH  /users/1        # Actualizar usuario parcial
DELETE /users/1        # Eliminar usuario

GET    /courses        # Obtener todos los cursos
GET    /courses/1      # Obtener curso por ID
POST   /courses        # Crear nuevo curso
PUT    /courses/1      # Actualizar curso
DELETE /courses/1      # Eliminar curso

GET    /enrollments    # Obtener todas las matrículas
POST   /enrollments    # Crear nueva matrícula
\`\`\`

### Consultas Avanzadas
\`\`\`bash
# Filtrar por campo
GET /users?role=admin
GET /courses?level=Principiante

# Ordenar
GET /courses?_sort=price&_order=asc

# Paginar
GET /users?_page=1&_limit=10

# Buscar
GET /courses?q=JavaScript

# Relaciones
GET /users/1/enrollments
GET /courses?_embed=enrollments

# Operadores
GET /courses?price_gte=50&price_lte=100
\`\`\`

## 🔧 Configuración Avanzada

### Middleware Personalizado
\`\`\`javascript
// middleware.js
module.exports = (req, res, next) => {
  // Agregar headers CORS
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,PATCH')
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  
  // Log de requests
  console.log(`${req.method} ${req.url}`)
  
  next()
}
\`\`\`

### Rutas Personalizadas
\`\`\`json
// routes.json
{
  "/api/*": "/$1",
  "/auth/login": "/sessions",
  "/auth/register": "/users",
  "/dashboard/stats": "/stats"
}
\`\`\`

### Uso con Rutas Personalizadas
\`\`\`bash
json-server --watch db.json --routes routes.json
\`\`\`

## 📊 Relaciones Entre Tablas

### Diagrama de Relaciones
\`\`\`
Users (1) -----> (N) Enrollments (N) <----- (1) Courses
  |                                              |
  |                                              |
  v                                              v
Sessions                                    Notifications
\`\`\`

### Consultas con Relaciones
\`\`\`javascript
// Obtener usuario con sus matrículas
GET /users/1?_embed=enrollments

// Obtener curso con estudiantes
GET /courses/1?_embed=enrollments&_expand=user

// Obtener matrícula con datos completos
GET /enrollments/1?_expand=user&_expand=course
\`\`\`

## 🐛 Datos de Prueba

### Usuarios de Prueba
- **Admin**: admin@admin.com / admin123
- **Usuario 1**: juan@email.com / user123
- **Usuario 2**: maria@email.com / user123

### Escenarios de Prueba
1. **Login Admin**: Acceso completo al dashboard
2. **Login Usuario**: Vista limitada, solo cursos
3. **Registro**: Crear nuevo usuario visitante
4. **Matrícula**: Inscribirse a un curso
5. **CRUD Cursos**: Solo admin puede gestionar

## 📈 Optimizaciones

### Índices Simulados
\`\`\`javascript
// Para búsquedas rápidas
GET /users?email=admin@admin.com
GET /courses?instructor=Felipe%20Hincapié
\`\`\`

### Backup y Restore
\`\`\`bash
# Backup
cp db.json db.backup.json

# Restore
cp db.backup.json db.json

# Reset a datos iniciales
git checkout db.json
\`\`\`

## 🔗 Enlaces Útiles
- [JSON Server Documentation](https://github.com/typicode/json-server)
- [REST API Design](https://restfulapi.net/)
- [HTTP Status Codes](https://httpstatuses.com/)

---
**Siguiente paso**: Configurar estructura de carpetas y archivos principales
